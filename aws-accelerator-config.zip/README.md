# Standard Configuration

The documentation for the standard sample configuration has been moved to the [Standard Configuration](https://awslabs.github.io/landing-zone-accelerator-on-aws/latest/sample-configurations/standard) section of our [GitHub Pages website](https://awslabs.github.io/landing-zone-accelerator-on-aws).